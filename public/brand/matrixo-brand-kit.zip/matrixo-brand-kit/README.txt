matriXO brand kit
=================

Logos
  matrixo-logo.svg / .png             Wordmark for light backgrounds
  matrixo-logo-white.svg / .png       Wordmark for dark backgrounds and photos
  matrixo-mark.svg / .png             XO monogram for light backgrounds
  matrixo-mark-white.svg / .png       XO monogram for dark backgrounds
  matrixo-app-icon.svg / -512.png     App icon, favicons and social avatars
  matrixo-app-icon-maskable-512.png   Square icon for platforms that apply their own mask

Colours
  Ink        #0A0A0B   wordmark, primary text
  Paper      #FFFFFF   light backgrounds
  Mist       #F5F5F7   light surfaces
  Night      #06070B   dark backgrounds
  XO Blue    #2283C5   the glow inside the O
  Signal     #0A6FD6   links and buttons on light UI
  Signal Dk  #4BA3F5   links and buttons on dark UI

Type
  Inter (rsms.me/inter) for interface, headings and body.

Usage
  - Keep clear space around the wordmark equal to the height of the "X".
  - Minimum size: 88 px wide on screen, 22 mm in print.
  - Don't recolour the glow, stretch, rotate, outline or add effects.
  - On photos, use the white version over a darkened area.

Brand page: https://matrixo.in/brand
Questions:  hello@matrixo.in
